# Antak-Shari-Game
A web portal that can randomly generate name from storage and start the game 
Using HTML, CSS , NODEJS, MONGODB
